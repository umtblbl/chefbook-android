package com.app.chefbook.Model.ServiceModel.ResponseModel

data class ProfileDetails(
    val biography: String,
    val mail: String,
    val nameSurName: String,
    val userName: String
)