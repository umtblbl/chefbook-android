package com.app.chefbook.Data.Remote.ApiHelper

import com.app.chefbook.Data.Remote.Interface.IUserService

interface IApiHelper: IUserService