package com.app.chefbook.Model.ServiceModel.RequestModel

class LoginUser (
    private val email: String,
    private val password: String
)