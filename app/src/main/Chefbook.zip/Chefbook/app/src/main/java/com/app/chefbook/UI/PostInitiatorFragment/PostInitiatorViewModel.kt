package com.app.chefbook.UI.PostInitiatorFragment

import androidx.lifecycle.ViewModel
import com.app.chefbook.Data.DataManager

class PostInitiatorViewModel(val dataManager: DataManager) : ViewModel() {
}