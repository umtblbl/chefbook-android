package com.app.chefbook.UI.Adapters

interface RecyclerViewOnClickListener {
    fun onClick(item: String)
}