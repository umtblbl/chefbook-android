package com.app.chefbook.UI.MainActivity

import androidx.lifecycle.ViewModel
import com.app.chefbook.Data.IDataManager


class MainViewModel(var dataManager: IDataManager) : ViewModel()


