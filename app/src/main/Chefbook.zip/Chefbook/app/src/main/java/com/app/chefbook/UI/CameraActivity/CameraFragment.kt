package com.app.chefbook.UI.CameraActivity


import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.app.chefbook.R
import kotlinx.android.synthetic.main.fragment_camera.*

class CameraFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_camera, container, false)
        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        btnCamera.setOnClickListener {
            Log.d("Camera", "btnImage")
        }

        btnCamera.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    Toast.makeText(context, "DOWN - START", Toast.LENGTH_SHORT).show()
                    Log.d("CameraOzel", "DOWN")

                }
                MotionEvent.ACTION_UP -> {
                    Toast.makeText(context, "UP - STOP", Toast.LENGTH_SHORT).show()
                    Log.d("CameraOzel", "UP")
                }
            }
            v?.onTouchEvent(event) ?: true
        }

        baslat.setOnClickListener {  }
        durdur.setOnClickListener {  }

    }
}





/*
        imgLoopCamera.setOnClickListener {
            if (cameraKitView.facing == CameraKit.Constants.FACING_BACK)
                cameraKitView.facing = CameraKit.Constants.FACING_FRONT
            else
                cameraKitView.facing = CameraKit.Constants.FACING_BACK
        }

        imgFlash.setOnClickListener {
            when (cameraKitView.flash) {

                CameraKit.Constants.FLASH_ON -> {
                    cameraKitView.flash = CameraKit.Constants.FLASH_AUTO
                    imgFlash.setImageResource(R.drawable.ic_flash_auto_white_24dp)
                }
                CameraKit.Constants.FLASH_AUTO -> {
                    cameraKitView.flash = CameraKit.Constants.FLASH_OFF
                    imgFlash.setImageResource(R.drawable.ic_flash_off_white_24dp)
                }
                else -> {
                    cameraKitView.flash = CameraKit.Constants.FLASH_ON
                    imgFlash.setImageResource(R.drawable.ic_flash_on_white_24dp)
                }
            }
        }*/
