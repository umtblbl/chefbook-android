package com.app.chefbook.Data

import com.app.chefbook.Data.Preferences.IPrefHelper
import com.app.chefbook.Data.Remote.ApiHelper.IApiHelper

interface IDataManager: IApiHelper, IPrefHelper