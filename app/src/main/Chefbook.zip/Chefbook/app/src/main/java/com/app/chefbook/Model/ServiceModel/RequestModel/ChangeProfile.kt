package com.app.chefbook.Model.ServiceModel.RequestModel

class ChangeProfile(
    private val userName: String,
    private val nameSurName: String,
    private val biography: String,
    private val mail: String
)