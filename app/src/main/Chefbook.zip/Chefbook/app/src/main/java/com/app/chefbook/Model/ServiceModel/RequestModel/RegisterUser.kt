package com.app.chefbook.Model.ServiceModel.RequestModel

class RegisterUser (
    private val userName: String,
    private val mail: String,
    private val password: String
)