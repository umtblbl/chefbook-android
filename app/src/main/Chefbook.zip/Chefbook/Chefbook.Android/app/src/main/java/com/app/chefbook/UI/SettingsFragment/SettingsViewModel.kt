package com.app.chefbook.UI.SettingsFragment

import androidx.lifecycle.ViewModel
import com.app.chefbook.Data.DataManager

class SettingsViewModel (val dataManager: DataManager) : ViewModel() {

}